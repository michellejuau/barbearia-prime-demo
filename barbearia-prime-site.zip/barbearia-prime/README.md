# Barbearia Prime — site demonstrativo

Site estático de uma página, sem API e sem banco de dados. Nome, valores, endereço e horários são fictícios.

## Visualizar
Abra `index.html` no navegador. Fotos externas requerem internet.

## Publicar
Crie um repositório no GitHub e envie `index.html` na raiz. Na Vercel, importe o repositório e escolha **Other**; não é necessário comando de build.

## Personalizar para um cliente
- Troque o nome "Barbearia Prime", título e textos no `index.html`.
- Atualize serviços, valores, horários, endereço e imagens (use imagens autorizadas).
- Ajuste as cores em `:root` no CSS ou nos botões de demonstração.
- Para ativar WhatsApp, substitua o botão `id="whats"` por um link como `<a class="btn" href="https://wa.me/5531999999999?text=Ol%C3%A1%2C%20quero%20agendar" target="_blank" rel="noopener noreferrer">Agendar pelo WhatsApp</a>` usando o número real com DDI e DDD; remova o event listener correspondente no script.
- Remova a faixa e os avisos de demonstração, a seção flutuante de cores (se não desejada) e atualize a política de uso de imagens antes de publicar o site real.

## Atenção
O site de demonstração não faz agendamentos nem representa um negócio real. Consulte os termos da hospedagem para uso comercial.
